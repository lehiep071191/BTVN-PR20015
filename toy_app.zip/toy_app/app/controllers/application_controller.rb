class ApplicationController < ActionController::Base
	def home
	render html:"xin chao cac ban den voi trang web cua le hiep" 
	end
end
