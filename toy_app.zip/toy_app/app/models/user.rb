class User < ApplicationRecord
	validates :name, length:{in: 6..12,  too_long: "viết lằm viết lốn" }, presence: true, uniqueness: true
	validates :email, length:{in: 6..30,  too_long: "viết lằm viết lốn" }, presence: true, uniqueness: true
end
