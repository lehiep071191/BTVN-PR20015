class Micropost < ApplicationRecord
	validates :content, length: {in: 0..140, too_long: "viết ít thôi, viết gì lắm thế" }
	validates :user_id, presence: true
end
